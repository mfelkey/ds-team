# Agentic TDD Team Playbook
## Version 1.0 (Frozen)

A stack-agnostic operating system for AI-assisted software teams.

Humans define intent. Tests encode intent. Agents implement.

See CONTRIBUTING.md for workflow and CHANGELOG.md for version history.
