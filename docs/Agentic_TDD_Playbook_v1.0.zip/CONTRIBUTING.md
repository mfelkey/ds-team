# Contributing Guide
## Agentic TDD Team Playbook — v1.0

Humans define intent. Tests encode intent. Agents implement.

Follow the R-G-R-G workflow:
1. Red — Write failing tests first
2. Green — Minimal implementation
3. Refactor — Improve structure
4. Guard — Add invariants and regression protection

Non-Negotiables:
- No behavior change without tests
- Deterministic tests only
- Main branch must remain green
- Zero flaky tests
