# Code of Conduct

We build disciplined, high-trust systems using human + AI collaboration.

Expected Behavior:
- Be respectful
- Critique ideas, not people
- Keep diffs small
- Preserve determinism

Unacceptable Behavior:
- Disrespectful communication
- Deleting tests to pass CI
- Introducing flaky tests
