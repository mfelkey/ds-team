# Changelog

## [1.0.0] - Initial Release

### Added
- Agentic TDD Team Playbook v1.0
- README.md
- CONTRIBUTING.md
- CODE_OF_CONDUCT.md

Version 1.0 is frozen baseline.
